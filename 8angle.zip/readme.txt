create database in phpmyadmin [anyname] eg: 8angle

open file 8angledb.txt  . Copy sql to 8angle database.

go to 8angle/includes/define.php

update database credentials DB_server , db_username , db_pasword , db_database , Base_url   

now run 8angle/index.php in your browser

register yourself .....  



Single user
Multi Companies