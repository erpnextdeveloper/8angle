<?php
echo getenv('DOCUMENT_ROOT');
?>