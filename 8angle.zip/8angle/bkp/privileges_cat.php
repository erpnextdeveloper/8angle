<tr align="left">
	<td class="textbdr">Companies</td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="companies_view" id="companies_view" value="1" <?php if($rowPrivilege['companies_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="companies_add" id="companies_add" value="1" <?php if($rowPrivilege['companies_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="companies_edit" id="companies_edit" value="1" <?php if($rowPrivilege['companies_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="companies_delete" id="companies_delete" value="1" <?php if($rowPrivilege['companies_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Assets</td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="assets_view" id="assets_view" value="1" <?php if($rowPrivilege['assets_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="assets_add" id="assets_add" value="1" <?php if($rowPrivilege['assets_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="assets_edit" id="assets_edit" value="1" <?php if($rowPrivilege['assets_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="assets_delete" id="assets_delete"  value="1" <?php if($rowPrivilege['assets_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Sale Customers</td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="customers_view" id="customers_view" value="1" <?php if($rowPrivilege['customers_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="customers_add" id="customers_add" value="1" <?php if($rowPrivilege['customers_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="customers_edit" id="customers_edit" value="1" <?php if($rowPrivilege['customers_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="customers_delete" id="customers_delete"  value="1" <?php if($rowPrivilege['customers_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Expenses</td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="expenses_view" id="expenses_view" value="1" <?php if($rowPrivilege['expenses_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="expenses_add" id="expenses_add" value="1" <?php if($rowPrivilege['expenses_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="expenses_edit" id="expenses_edit" value="1" <?php if($rowPrivilege['expenses_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="expenses_delete" id="expenses_delete"  value="1" <?php if($rowPrivilege['expenses_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Accessories</td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="invoice_tax_view" id="invoice_tax_view" value="1" <?php if($rowPrivilege['invoice_tax_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="invoice_tax_add" id="invoice_tax_add" value="1" <?php if($rowPrivilege['invoice_tax_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="invoice_tax_edit" id="invoice_tax_edit" value="1" <?php if($rowPrivilege['invoice_tax_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="invoice_tax_delete" id="invoice_tax_delete"  value="1" <?php if($rowPrivilege['invoice_tax_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Sale Invoice </td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="orders_view" id="orders_view" value="1" <?php if($rowPrivilege['orders_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="orders_add" id="orders_add" value="1" <?php if($rowPrivilege['orders_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="orders_edit" id="orders_edit" value="1" <?php if($rowPrivilege['orders_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="orders_delete" id="orders_delete"  value="1" <?php if($rowPrivilege['orders_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Inventory Management </td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="products_view" id="products_view" value="1" <?php if($rowPrivilege['products_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="products_add" id="products_add" value="1" <?php if($rowPrivilege['products_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="products_edit" id="products_edit" value="1" <?php if($rowPrivilege['products_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="products_delete" id="products_delete"  value="1" <?php if($rowPrivilege['products_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Stock Management </td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="stock_view" id="stock_view" value="1" <?php if($rowPrivilege['stock_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Users Management </td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="users_view" id="users_view" value="1" <?php if($rowPrivilege['users_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="users_add" id="users_add" value="1" <?php if($rowPrivilege['users_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="users_edit" id="users_edit" value="1" <?php if($rowPrivilege['users_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="users_delete" id="users_delete"  value="1" <?php if($rowPrivilege['users_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Purchase Invoice </td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="vendor_orders_view" id="vendor_orders_view" value="1" <?php if($rowPrivilege['vendor_orders_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="vendor_orders_add" id="vendor_orders_add" value="1" <?php if($rowPrivilege['vendor_orders_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="vendor_orders_edit" id="vendor_orders_edit" value="1" <?php if($rowPrivilege['vendor_orders_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="vendor_orders_delete" id="vendor_orders_delete"  value="1" <?php if($rowPrivilege['vendor_orders_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
<tr align="left">
	<td class="textbdr">Vendors Management </td>
	<td align="left" class="textbdr">
     	<input type="checkbox" name="vendors_view" id="vendors_view" value="1" <?php if($rowPrivilege['vendors_view']==1) { echo "checked='checked'";} ?><label>View</label>&nbsp;
   		<input type="checkbox" name="vendors_add" id="vendors_add" value="1" <?php if($rowPrivilege['vendors_add']==1) { echo "checked='checked'";} ?><label>Add </label>&nbsp;
      	<input type="checkbox" name="vendors_edit" id="vendors_edit" value="1" <?php if($rowPrivilege['vendors_edit']==1) { echo "checked='checked'";} ?><label>Edit </label>&nbsp;
    	<input type="checkbox" name="vendors_delete" id="vendors_delete"  value="1" <?php if($rowPrivilege['vendors_delete']==1) { echo "checked='checked'";} ?><label> Delete</label>
	</td>
</tr>
  